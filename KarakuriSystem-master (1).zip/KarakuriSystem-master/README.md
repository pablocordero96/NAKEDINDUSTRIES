# KarakuriSystem
Integrantes del equipo:
  <br>Cordero Hernádez Pablo Cesar 2015600437<br/>
  <br>García Márquez Jennifer Monserrat 2016600578<br/>
  <br>Hinojosa Maldonado Fernando 2016600825<br/>
  <br>Medina Rosales Jhonatan Jovanny 2016601064<br/>
  <br>Osorio Cuello Edgar Hiram 2016602330<br/>
  <br>Pastrana Jiménez Brenda Sulem 2016602726<br/>
